How to Set Up in Unity:

	Load HalloweenDuckHunt folder in Unity

	Open Main Menu Scene, run it, and play!

-----------------------------

How to Play:

	Shoot ghosts and witches to get a highscore and go through as many levels as possible.

	Shoot by clicking on enemies that spawn.

	Ghosts are 1 hit and Witches are 3 hits.


Special Mode:

	This will spawn a lot of ghosts in 3 seconds and you can hold down your mouse to kill them all (automatic firing)

	Special mode can be activated every 2 levels (2, 4, ...)

	Activate with Key X

-----------------------------

Assets:
	
	Art done by me
		Main Menu art done by a friend

	Sounds:
		Background:
			https://freesound.org/people/dAmbient/sounds/251936/
			https://freesound.org/people/DRFX/sounds/338986/

		Sound Effects:
			https://freesound.org/people/annabloom/sounds/219069/
			https://freesound.org/people/V-ktor/sounds/435417/
			https://freesound.org/people/Raclure/sounds/405548/
			https://freesound.org/people/alpharo/sounds/186696/
			https://www.101soundboards.com/sounds/10740-dog-laughing

		Font:
			https://www.dafont.com/blood-crow.font

